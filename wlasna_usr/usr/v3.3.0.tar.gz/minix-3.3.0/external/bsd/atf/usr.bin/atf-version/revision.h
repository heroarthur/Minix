/*	$NetBSD: revision.h,v 1.1 2010/07/03 08:14:13 jmmv Exp $	*/

#define PACKAGE_REVISION_TYPE_DIST
